Back-to-Roots Database Forms and Reports Developed by Hannah McDonald
Peer Reviewed by Emily Sandberg May, 30 2021
Orginally Developed: May 2021 | Updated: June 1, 2021
-------------------------------------------------------------------------------------------------------------------------------------------------
Step-by-Step Instructions:
-------------------------------------
Step 1: Run the BuildBackToRoots.sql script in SSMS to build the database (change the data path on line 21 as needed)
-------
Step 2: Run the BackToRootsView.sql in SSMS to create the view 
		* Used for the OrderSearch form and the order history subform on the Customer form
-------
Step 3: Windows Integrated Application	
	- Part I: Publish the solution locally
		1) Open the BackToRoots solution in Visual Studio
		2) On the Solution Explorer, right click "BackToRootsForms" and click "Publish"
		3) Click "Browse" and select a location on your computer to save the executable (I recommend a temp folder); click "Next"
		4) Esure the "From a CD-ROM or DVD-ROM" option is selected; click "Next"
		5) Ensure "The application will not check for updates" is selected (this is sufficient for the current purposes); click "Next"
		6) It is now ready to publish; click "Finish"
		7) Close Visual Studio
		8) Naviagate to the location on your computer in which you published the executable (this may automatically open)
		9) Open "setup.exe"
	- Part II: Explore the forms:
		* Use the buttons or menu at the top to open the forms you wish to view; each form has a menu at the top, so you can use that to navigate between forms
		1) Click the "Order Search" button to open the Order Search form
		2) Using the defaults, click the "Search" button
		3) Check the "Search all employees" box and click the "Search" button again
			* This might take a moment to load
		4) Change the "Placement" method using the combo box to a different selection
			* Notice the "Fulfillment" method changes accordingly to ensure only possible placement and fulfillment combinations are searched
		5) With the "Placement" method set to "Online," change the "Fulfillment" method to "In-Store"
			* Notice the error to ensure only possible placement and fulfillment combinations are searched
			* Can test a variety of other "Placement" and "Fulfillment" combinations
		6) Change the employee to "Aliza Lamb-shine" (uncheck all employees option if needed), the location to "Longmont," the placement to "Phone," and the fulfillment to "Pick-Up." Click the "Search" button
			* Message notifying user that no orders are found
		7) Continue testing different options as you see fit
		8) Search a combination that displays results. Then, double click on an OrderID to bring-up the Order form
		9) After double clicking on an OrderID from the OrderSearch form, click "Fill All"
		10) Scroll through some records 
		11) Search for a record between 1 and 200000 in the search bar (press enter or click "Search")
		12) Search for a record greater than 200000 (press enter or click "Search")
		13) Make changes to an order on the main form and subform. Try different combinations of order placement and fulfillment (notice validation). Click save to save those changes to the database
		14) On a record of you choosing, click "Customer Details"
		15) After clicking the "Customer Details" button on the Orders form, click "Fill All"
		16) Scroll through some records
			* Make sure to view records with varying reward status tiers. Notice the note displaying how much the customer needs to spend to reach the next rewards tier
			* Masks are used on the phone number and zip code fields because the small, local bakery does not anticipate international phone numbers or zip codes
		17) Search for "Mogg" in the search bar (press enter or click "Search")
		18) Search for "Hew%" in the search bar (press enter or click "Search")
		19) Search for "McDonald" in the search bar (press enter or click "Search")
		20) Make changes to a customer's information. Click save to save those changes to the database
		21) Double click on an OrderID to bring-up the Order form; close the Order form by clicking the "Close" button
		22) On a record of your choosing, click "Rewards Information"
		23) After clicking the "Rewards Information" button on the Customer form, scroll through records
		24) Change a description or perk as you see fit
		25) Click save to save the changes to the database
		26) Use the "Close" button on each opened form to close it
		27) Use the "Close" button on the Startup form to stop running the application (once all other open form windows are closed)
	
		Note: On the Order form and Customer form, can click the '+' to add a record (notice the ID auto-populates). On the Order form, fill all fields. 
			  On the Customer form, enter the first and last name. To navigate back through records, must close and reopen the form.
-------
Step 4: Open Visual Studio; Then, open the "EmployeePerformance.rdl" report in preview mode
	* Note the graph displaying the orders filled by each employee
	* Note default parameters have been set
	- Explore the report:
		1) Open the details on each position name to see information on the employees and their performance
		2) Adjust the "Report Start Date" parameter and "Report End Date" parameter to be for any window of time between the defaults--2/1/2018 and 3/31/2021
			a) Try the date range 10/1/2019 to 12/31/2019 (Q3 2019)
			b) Try the date range 4/1/2020 to 5/31/2020 (COVID-19 months)
			c) Try the date range 1/1/2021 to 1/31/2021 (January 2021)
	- BUSINESS PURPOSE: This report will inform users of the orders filled and total sales by each employee, in a user-specified date range. 
	  The employees' wage and the number of days each employee worked in the specified date range is also included to add further insight into employee performance.
	  This provides management with information regarding employee performance in terms of order fulfillment and sales. One practical implication of this report is 
	  management’s allocation of employee-support resources, including training, and information in promotion, wage, and firing decisions.
	  Currently, the number of hours an employee works is not stored in this database, so an employee's schedule can only be determined by whether there was an 
	  order in their name on a given day. Thus, one employee may have worked two hours while another worked eight hours, but for this analysis, both employees worked one day. 
	  Knowing this limitation, it may be useful to begin recording this information for better employee performance analysis.
-------	
Step 5: Open the "ProductSales.rdl" report in Visual Studio in preview mode
	* Note the graph displaying the sales trend for the year
	* Note the graph displaying the sales for each product type
	* Note default parameters have been set
	- Explore the report:
		1) Open the details on each product type to see sales information for each product
		2) Open the details on year to see sales information for each month
		3) Choose different parameters for "Year" and "Location" from the dropdowns as you see fit
	- BUSINESS PURPOSE: This report informs users the quantity sold and total sales for each product type, and the products within those types, for a user-specified 
	  year and store location(s). This provides management with information regarding the volume of sales by product in a given year, with the ability to view that by 
	  month and to specify store location. One practical implication of this report is management’s purchasing and directing of inventory based on products' popularity 
	  in a given month and at a given store location.
-------------------------------------------------------------------------------------------------------------------------------------------------