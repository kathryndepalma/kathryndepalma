﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Customers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim lblCustomerID As System.Windows.Forms.Label
        Dim lblCustomerFirstName As System.Windows.Forms.Label
        Dim lblCustomerLastName As System.Windows.Forms.Label
        Dim lblCustomerDOB As System.Windows.Forms.Label
        Dim lblCustomerEmail As System.Windows.Forms.Label
        Dim lblCustomerPhoneNumber As System.Windows.Forms.Label
        Dim lblCustomerStreetAddress As System.Windows.Forms.Label
        Dim lblCustomerCity As System.Windows.Forms.Label
        Dim lblCustomerState As System.Windows.Forms.Label
        Dim lblCustomerZipCode As System.Windows.Forms.Label
        Dim lblRewardHistory As System.Windows.Forms.Label
        Dim lblCurrentRewardStatusTitle As System.Windows.Forms.Label
        Dim lblOrderHistory As System.Windows.Forms.Label
        Dim lblTotalSpentTitle As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Customers))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lblCustomers = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.CustomerBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.CustomerBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BackToRootsDataSet = New BackToRootsForms.BackToRootsDataSet()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CustomerBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.txtCustomerID = New System.Windows.Forms.TextBox()
        Me.txtCustomerFirstName = New System.Windows.Forms.TextBox()
        Me.txtCustomerLastName = New System.Windows.Forms.TextBox()
        Me.CustomerEmailTextBox = New System.Windows.Forms.TextBox()
        Me.CustomerStreetAddressTextBox = New System.Windows.Forms.TextBox()
        Me.CustomerCityTextBox = New System.Windows.Forms.TextBox()
        Me.CustomerStateTextBox = New System.Windows.Forms.TextBox()
        Me.RewardHistoryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RewardHistoryDataGridView = New System.Windows.Forms.DataGridView()
        Me.RewardStatusBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerOrderBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblCurrentRewardStatus = New System.Windows.Forms.Label()
        Me.FillByToolStrip = New System.Windows.Forms.ToolStrip()
        Me.CustomerLastNameToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.txtCustomerLastNameSearch = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.btnFillAll = New System.Windows.Forms.ToolStripButton()
        Me.CustomerPhoneMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.ZipCodeMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.btnRewardsInfo = New System.Windows.Forms.Button()
        Me.FillByIDToolStrip = New System.Windows.Forms.ToolStrip()
        Me.CustomerIDToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.CustomerIDToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByIDToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.OrderSearchBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrderSearchDataGridView = New System.Windows.Forms.DataGridView()
        Me.EmployeeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StoreLocationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CustomerTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.CustomerTableAdapter()
        Me.TableAdapterManager = New BackToRootsForms.BackToRootsDataSetTableAdapters.TableAdapterManager()
        Me.RewardHistoryTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.RewardHistoryTableAdapter()
        Me.RewardStatusTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.RewardStatusTableAdapter()
        Me.CustomerOrderTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.CustomerOrderTableAdapter()
        Me.EmployeeTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.EmployeeTableAdapter()
        Me.StoreLocationTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.StoreLocationTableAdapter()
        Me.CustomerBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrderPlacementBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrderPlacementTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.OrderPlacementTableAdapter()
        Me.OrderFulfillmentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OrderFulfillmentTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.OrderFulfillmentTableAdapter()
        Me.OrderSearchTableAdapter = New BackToRootsForms.BackToRootsDataSetTableAdapters.OrderSearchTableAdapter()
        Me.lblTotalSpent = New System.Windows.Forms.Label()
        Me.lblNextRewardTier = New System.Windows.Forms.Label()
        Me.DOBMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.OrderSearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManagementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrdersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManagementToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RewardStatusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RewardStatus = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrderID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrderTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        lblCustomerID = New System.Windows.Forms.Label()
        lblCustomerFirstName = New System.Windows.Forms.Label()
        lblCustomerLastName = New System.Windows.Forms.Label()
        lblCustomerDOB = New System.Windows.Forms.Label()
        lblCustomerEmail = New System.Windows.Forms.Label()
        lblCustomerPhoneNumber = New System.Windows.Forms.Label()
        lblCustomerStreetAddress = New System.Windows.Forms.Label()
        lblCustomerCity = New System.Windows.Forms.Label()
        lblCustomerState = New System.Windows.Forms.Label()
        lblCustomerZipCode = New System.Windows.Forms.Label()
        lblRewardHistory = New System.Windows.Forms.Label()
        lblCurrentRewardStatusTitle = New System.Windows.Forms.Label()
        lblOrderHistory = New System.Windows.Forms.Label()
        lblTotalSpentTitle = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CustomerBindingNavigator.SuspendLayout()
        CType(Me.CustomerBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BackToRootsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RewardHistoryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RewardHistoryDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RewardStatusBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerOrderBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillByToolStrip.SuspendLayout()
        Me.FillByIDToolStrip.SuspendLayout()
        CType(Me.OrderSearchBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderSearchDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StoreLocationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomerBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderPlacementBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OrderFulfillmentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblCustomerID
        '
        lblCustomerID.AutoSize = True
        lblCustomerID.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCustomerID.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomerID.Location = New System.Drawing.Point(279, 167)
        lblCustomerID.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomerID.Name = "lblCustomerID"
        lblCustomerID.Size = New System.Drawing.Size(109, 22)
        lblCustomerID.TabIndex = 0
        lblCustomerID.Text = "Customer ID"
        '
        'lblCustomerFirstName
        '
        lblCustomerFirstName.AutoSize = True
        lblCustomerFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCustomerFirstName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomerFirstName.Location = New System.Drawing.Point(291, 210)
        lblCustomerFirstName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomerFirstName.Name = "lblCustomerFirstName"
        lblCustomerFirstName.Size = New System.Drawing.Size(97, 22)
        lblCustomerFirstName.TabIndex = 2
        lblCustomerFirstName.Text = "First Name"
        '
        'lblCustomerLastName
        '
        lblCustomerLastName.AutoSize = True
        lblCustomerLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCustomerLastName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomerLastName.Location = New System.Drawing.Point(665, 210)
        lblCustomerLastName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomerLastName.Name = "lblCustomerLastName"
        lblCustomerLastName.Size = New System.Drawing.Size(96, 22)
        lblCustomerLastName.TabIndex = 4
        lblCustomerLastName.Text = "Last Name"
        '
        'lblCustomerDOB
        '
        lblCustomerDOB.AutoSize = True
        lblCustomerDOB.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCustomerDOB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomerDOB.Location = New System.Drawing.Point(691, 336)
        lblCustomerDOB.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomerDOB.Name = "lblCustomerDOB"
        lblCustomerDOB.Size = New System.Drawing.Size(76, 22)
        lblCustomerDOB.TabIndex = 18
        lblCustomerDOB.Text = "Birthday"
        '
        'lblCustomerEmail
        '
        lblCustomerEmail.AutoSize = True
        lblCustomerEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCustomerEmail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomerEmail.Location = New System.Drawing.Point(329, 250)
        lblCustomerEmail.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomerEmail.Name = "lblCustomerEmail"
        lblCustomerEmail.Size = New System.Drawing.Size(54, 22)
        lblCustomerEmail.TabIndex = 6
        lblCustomerEmail.Text = "Email"
        '
        'lblCustomerPhoneNumber
        '
        lblCustomerPhoneNumber.AutoSize = True
        lblCustomerPhoneNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCustomerPhoneNumber.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomerPhoneNumber.Location = New System.Drawing.Point(698, 250)
        lblCustomerPhoneNumber.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomerPhoneNumber.Name = "lblCustomerPhoneNumber"
        lblCustomerPhoneNumber.Size = New System.Drawing.Size(62, 22)
        lblCustomerPhoneNumber.TabIndex = 8
        lblCustomerPhoneNumber.Text = "Phone"
        '
        'lblCustomerStreetAddress
        '
        lblCustomerStreetAddress.AutoSize = True
        lblCustomerStreetAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCustomerStreetAddress.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomerStreetAddress.Location = New System.Drawing.Point(263, 293)
        lblCustomerStreetAddress.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomerStreetAddress.Name = "lblCustomerStreetAddress"
        lblCustomerStreetAddress.Size = New System.Drawing.Size(129, 22)
        lblCustomerStreetAddress.TabIndex = 10
        lblCustomerStreetAddress.Text = "Street Address"
        '
        'lblCustomerCity
        '
        lblCustomerCity.AutoSize = True
        lblCustomerCity.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCustomerCity.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomerCity.Location = New System.Drawing.Point(717, 293)
        lblCustomerCity.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomerCity.Name = "lblCustomerCity"
        lblCustomerCity.Size = New System.Drawing.Size(41, 22)
        lblCustomerCity.TabIndex = 12
        lblCustomerCity.Text = "City"
        '
        'lblCustomerState
        '
        lblCustomerState.AutoSize = True
        lblCustomerState.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCustomerState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomerState.Location = New System.Drawing.Point(333, 336)
        lblCustomerState.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomerState.Name = "lblCustomerState"
        lblCustomerState.Size = New System.Drawing.Size(52, 22)
        lblCustomerState.TabIndex = 14
        lblCustomerState.Text = "State"
        '
        'lblCustomerZipCode
        '
        lblCustomerZipCode.AutoSize = True
        lblCustomerZipCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCustomerZipCode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCustomerZipCode.Location = New System.Drawing.Point(481, 336)
        lblCustomerZipCode.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCustomerZipCode.Name = "lblCustomerZipCode"
        lblCustomerZipCode.Size = New System.Drawing.Size(83, 22)
        lblCustomerZipCode.TabIndex = 16
        lblCustomerZipCode.Text = "Zip Code"
        '
        'lblRewardHistory
        '
        lblRewardHistory.AutoSize = True
        lblRewardHistory.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblRewardHistory.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblRewardHistory.Location = New System.Drawing.Point(42, 409)
        lblRewardHistory.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblRewardHistory.Name = "lblRewardHistory"
        lblRewardHistory.Size = New System.Drawing.Size(133, 22)
        lblRewardHistory.TabIndex = 20
        lblRewardHistory.Text = "Reward History"
        '
        'lblCurrentRewardStatusTitle
        '
        lblCurrentRewardStatusTitle.AutoSize = True
        lblCurrentRewardStatusTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblCurrentRewardStatusTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblCurrentRewardStatusTitle.Location = New System.Drawing.Point(31, 610)
        lblCurrentRewardStatusTitle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblCurrentRewardStatusTitle.Name = "lblCurrentRewardStatusTitle"
        lblCurrentRewardStatusTitle.Size = New System.Drawing.Size(202, 22)
        lblCurrentRewardStatusTitle.TabIndex = 23
        lblCurrentRewardStatusTitle.Text = "Current Rewards Status"
        '
        'lblOrderHistory
        '
        lblOrderHistory.AutoSize = True
        lblOrderHistory.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblOrderHistory.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblOrderHistory.Location = New System.Drawing.Point(429, 409)
        lblOrderHistory.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblOrderHistory.Name = "lblOrderHistory"
        lblOrderHistory.Size = New System.Drawing.Size(117, 22)
        lblOrderHistory.TabIndex = 25
        lblOrderHistory.Text = "Order History"
        '
        'lblTotalSpentTitle
        '
        lblTotalSpentTitle.AutoSize = True
        lblTotalSpentTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblTotalSpentTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        lblTotalSpentTitle.Location = New System.Drawing.Point(927, 610)
        lblTotalSpentTitle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        lblTotalSpentTitle.Name = "lblTotalSpentTitle"
        lblTotalSpentTitle.Size = New System.Drawing.Size(103, 22)
        lblTotalSpentTitle.TabIndex = 28
        lblTotalSpentTitle.Text = "Total Spent"
        '
        'lblCustomers
        '
        Me.lblCustomers.AutoSize = True
        Me.lblCustomers.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomers.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblCustomers.Location = New System.Drawing.Point(518, 111)
        Me.lblCustomers.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCustomers.Name = "lblCustomers"
        Me.lblCustomers.Size = New System.Drawing.Size(188, 31)
        Me.lblCustomers.TabIndex = 8
        Me.lblCustomers.Text = "CUSTOMERS"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(439, 67)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(367, 39)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Back-to-Roots Bakery"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(1046, 48)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(118, 166)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'CustomerBindingNavigator
        '
        Me.CustomerBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.CustomerBindingNavigator.BindingSource = Me.CustomerBindingSource
        Me.CustomerBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.CustomerBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.CustomerBindingNavigator.Dock = System.Windows.Forms.DockStyle.None
        Me.CustomerBindingNavigator.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.CustomerBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.CustomerBindingNavigatorSaveItem})
        Me.CustomerBindingNavigator.Location = New System.Drawing.Point(6, 39)
        Me.CustomerBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.CustomerBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.CustomerBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.CustomerBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.CustomerBindingNavigator.Name = "CustomerBindingNavigator"
        Me.CustomerBindingNavigator.Padding = New System.Windows.Forms.Padding(0, 0, 2, 0)
        Me.CustomerBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.CustomerBindingNavigator.Size = New System.Drawing.Size(274, 27)
        Me.CustomerBindingNavigator.TabIndex = 9
        Me.CustomerBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'CustomerBindingSource
        '
        Me.CustomerBindingSource.DataMember = "Customer"
        Me.CustomerBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'BackToRootsDataSet
        '
        Me.BackToRootsDataSet.DataSetName = "BackToRootsDataSet"
        Me.BackToRootsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 24)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Enabled = False
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(38, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(24, 24)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 27)
        '
        'CustomerBindingNavigatorSaveItem
        '
        Me.CustomerBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CustomerBindingNavigatorSaveItem.Image = CType(resources.GetObject("CustomerBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.CustomerBindingNavigatorSaveItem.Name = "CustomerBindingNavigatorSaveItem"
        Me.CustomerBindingNavigatorSaveItem.Size = New System.Drawing.Size(24, 24)
        Me.CustomerBindingNavigatorSaveItem.Text = "Save Data"
        '
        'txtCustomerID
        '
        Me.txtCustomerID.BackColor = System.Drawing.Color.LightGray
        Me.txtCustomerID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerID", True))
        Me.txtCustomerID.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerID.Location = New System.Drawing.Point(395, 165)
        Me.txtCustomerID.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txtCustomerID.Name = "txtCustomerID"
        Me.txtCustomerID.ReadOnly = True
        Me.txtCustomerID.Size = New System.Drawing.Size(108, 27)
        Me.txtCustomerID.TabIndex = 1
        '
        'txtCustomerFirstName
        '
        Me.txtCustomerFirstName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerFirstName", True))
        Me.txtCustomerFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerFirstName.Location = New System.Drawing.Point(395, 207)
        Me.txtCustomerFirstName.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txtCustomerFirstName.Name = "txtCustomerFirstName"
        Me.txtCustomerFirstName.Size = New System.Drawing.Size(257, 27)
        Me.txtCustomerFirstName.TabIndex = 3
        '
        'txtCustomerLastName
        '
        Me.txtCustomerLastName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerLastName", True))
        Me.txtCustomerLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerLastName.Location = New System.Drawing.Point(768, 207)
        Me.txtCustomerLastName.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.txtCustomerLastName.Name = "txtCustomerLastName"
        Me.txtCustomerLastName.Size = New System.Drawing.Size(182, 27)
        Me.txtCustomerLastName.TabIndex = 5
        '
        'CustomerEmailTextBox
        '
        Me.CustomerEmailTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerEmail", True))
        Me.CustomerEmailTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerEmailTextBox.Location = New System.Drawing.Point(395, 248)
        Me.CustomerEmailTextBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CustomerEmailTextBox.Name = "CustomerEmailTextBox"
        Me.CustomerEmailTextBox.Size = New System.Drawing.Size(257, 27)
        Me.CustomerEmailTextBox.TabIndex = 7
        '
        'CustomerStreetAddressTextBox
        '
        Me.CustomerStreetAddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerStreetAddress", True))
        Me.CustomerStreetAddressTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerStreetAddressTextBox.Location = New System.Drawing.Point(395, 290)
        Me.CustomerStreetAddressTextBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CustomerStreetAddressTextBox.Name = "CustomerStreetAddressTextBox"
        Me.CustomerStreetAddressTextBox.Size = New System.Drawing.Size(257, 27)
        Me.CustomerStreetAddressTextBox.TabIndex = 11
        '
        'CustomerCityTextBox
        '
        Me.CustomerCityTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerCity", True))
        Me.CustomerCityTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerCityTextBox.Location = New System.Drawing.Point(768, 290)
        Me.CustomerCityTextBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CustomerCityTextBox.Name = "CustomerCityTextBox"
        Me.CustomerCityTextBox.Size = New System.Drawing.Size(182, 27)
        Me.CustomerCityTextBox.TabIndex = 13
        '
        'CustomerStateTextBox
        '
        Me.CustomerStateTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerState", True))
        Me.CustomerStateTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerStateTextBox.Location = New System.Drawing.Point(395, 334)
        Me.CustomerStateTextBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CustomerStateTextBox.Name = "CustomerStateTextBox"
        Me.CustomerStateTextBox.Size = New System.Drawing.Size(72, 27)
        Me.CustomerStateTextBox.TabIndex = 15
        '
        'RewardHistoryBindingSource
        '
        Me.RewardHistoryBindingSource.DataMember = "fk_reward_history_customer_id"
        Me.RewardHistoryBindingSource.DataSource = Me.CustomerBindingSource
        '
        'RewardHistoryDataGridView
        '
        Me.RewardHistoryDataGridView.AllowUserToAddRows = False
        Me.RewardHistoryDataGridView.AllowUserToDeleteRows = False
        Me.RewardHistoryDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.RewardHistoryDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.RewardHistoryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.RewardHistoryDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RewardStatus, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.RewardHistoryDataGridView.DataSource = Me.RewardHistoryBindingSource
        Me.RewardHistoryDataGridView.Location = New System.Drawing.Point(35, 439)
        Me.RewardHistoryDataGridView.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.RewardHistoryDataGridView.Name = "RewardHistoryDataGridView"
        Me.RewardHistoryDataGridView.ReadOnly = True
        Me.RewardHistoryDataGridView.RowHeadersWidth = 51
        Me.RewardHistoryDataGridView.RowTemplate.Height = 24
        Me.RewardHistoryDataGridView.Size = New System.Drawing.Size(366, 158)
        Me.RewardHistoryDataGridView.TabIndex = 21
        '
        'RewardStatusBindingSource
        '
        Me.RewardStatusBindingSource.DataMember = "RewardStatus"
        Me.RewardStatusBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'CustomerOrderBindingSource
        '
        Me.CustomerOrderBindingSource.DataMember = "fk_order_customer_id"
        Me.CustomerOrderBindingSource.DataSource = Me.CustomerBindingSource
        '
        'lblCurrentRewardStatus
        '
        Me.lblCurrentRewardStatus.AutoSize = True
        Me.lblCurrentRewardStatus.BackColor = System.Drawing.Color.FromArgb(CType(CType(117, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.lblCurrentRewardStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentRewardStatus.ForeColor = System.Drawing.Color.LightGray
        Me.lblCurrentRewardStatus.Location = New System.Drawing.Point(262, 610)
        Me.lblCurrentRewardStatus.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCurrentRewardStatus.Name = "lblCurrentRewardStatus"
        Me.lblCurrentRewardStatus.Size = New System.Drawing.Size(139, 24)
        Me.lblCurrentRewardStatus.TabIndex = 24
        Me.lblCurrentRewardStatus.Text = "NO REWARDS"
        '
        'FillByToolStrip
        '
        Me.FillByToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.FillByToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.FillByToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomerLastNameToolStripLabel, Me.txtCustomerLastNameSearch, Me.FillByToolStripButton, Me.btnFillAll})
        Me.FillByToolStrip.Location = New System.Drawing.Point(9, 77)
        Me.FillByToolStrip.Name = "FillByToolStrip"
        Me.FillByToolStrip.Padding = New System.Windows.Forms.Padding(0, 0, 2, 0)
        Me.FillByToolStrip.Size = New System.Drawing.Size(246, 25)
        Me.FillByToolStrip.TabIndex = 33
        Me.FillByToolStrip.Text = "FillByToolStrip"
        '
        'CustomerLastNameToolStripLabel
        '
        Me.CustomerLastNameToolStripLabel.Name = "CustomerLastNameToolStripLabel"
        Me.CustomerLastNameToolStripLabel.Size = New System.Drawing.Size(66, 22)
        Me.CustomerLastNameToolStripLabel.Text = "Last Name:"
        '
        'txtCustomerLastNameSearch
        '
        Me.txtCustomerLastNameSearch.Name = "txtCustomerLastNameSearch"
        Me.txtCustomerLastNameSearch.Size = New System.Drawing.Size(76, 25)
        '
        'FillByToolStripButton
        '
        Me.FillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByToolStripButton.Name = "FillByToolStripButton"
        Me.FillByToolStripButton.Size = New System.Drawing.Size(46, 22)
        Me.FillByToolStripButton.Text = "Search"
        '
        'btnFillAll
        '
        Me.btnFillAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnFillAll.Image = CType(resources.GetObject("btnFillAll.Image"), System.Drawing.Image)
        Me.btnFillAll.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnFillAll.Name = "btnFillAll"
        Me.btnFillAll.Size = New System.Drawing.Size(43, 22)
        Me.btnFillAll.Text = "Fill All"
        '
        'CustomerPhoneMaskedTextBox
        '
        Me.CustomerPhoneMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerPhoneNumber", True))
        Me.CustomerPhoneMaskedTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerPhoneMaskedTextBox.Location = New System.Drawing.Point(768, 248)
        Me.CustomerPhoneMaskedTextBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.CustomerPhoneMaskedTextBox.Mask = "999-000-0000"
        Me.CustomerPhoneMaskedTextBox.Name = "CustomerPhoneMaskedTextBox"
        Me.CustomerPhoneMaskedTextBox.Size = New System.Drawing.Size(182, 27)
        Me.CustomerPhoneMaskedTextBox.TabIndex = 9
        '
        'ZipCodeMaskedTextBox
        '
        Me.ZipCodeMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerZipCode", True))
        Me.ZipCodeMaskedTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZipCodeMaskedTextBox.Location = New System.Drawing.Point(561, 334)
        Me.ZipCodeMaskedTextBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.ZipCodeMaskedTextBox.Mask = "00000-9999"
        Me.ZipCodeMaskedTextBox.Name = "ZipCodeMaskedTextBox"
        Me.ZipCodeMaskedTextBox.Size = New System.Drawing.Size(111, 27)
        Me.ZipCodeMaskedTextBox.TabIndex = 17
        '
        'btnRewardsInfo
        '
        Me.btnRewardsInfo.Location = New System.Drawing.Point(322, 400)
        Me.btnRewardsInfo.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.btnRewardsInfo.Name = "btnRewardsInfo"
        Me.btnRewardsInfo.Size = New System.Drawing.Size(72, 35)
        Me.btnRewardsInfo.TabIndex = 22
        Me.btnRewardsInfo.Text = "Rewards Information"
        Me.btnRewardsInfo.UseVisualStyleBackColor = True
        '
        'FillByIDToolStrip
        '
        Me.FillByIDToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.FillByIDToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.FillByIDToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomerIDToolStripLabel, Me.CustomerIDToolStripTextBox, Me.FillByIDToolStripButton})
        Me.FillByIDToolStrip.Location = New System.Drawing.Point(7, 64)
        Me.FillByIDToolStrip.Name = "FillByIDToolStrip"
        Me.FillByIDToolStrip.Padding = New System.Windows.Forms.Padding(0, 0, 2, 0)
        Me.FillByIDToolStrip.Size = New System.Drawing.Size(190, 25)
        Me.FillByIDToolStrip.TabIndex = 37
        Me.FillByIDToolStrip.Text = "FillByIDToolStrip"
        Me.FillByIDToolStrip.Visible = False
        '
        'CustomerIDToolStripLabel
        '
        Me.CustomerIDToolStripLabel.Name = "CustomerIDToolStripLabel"
        Me.CustomerIDToolStripLabel.Size = New System.Drawing.Size(73, 22)
        Me.CustomerIDToolStripLabel.Text = "CustomerID:"
        '
        'CustomerIDToolStripTextBox
        '
        Me.CustomerIDToolStripTextBox.Name = "CustomerIDToolStripTextBox"
        Me.CustomerIDToolStripTextBox.Size = New System.Drawing.Size(52, 25)
        '
        'FillByIDToolStripButton
        '
        Me.FillByIDToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByIDToolStripButton.Name = "FillByIDToolStripButton"
        Me.FillByIDToolStripButton.Size = New System.Drawing.Size(50, 22)
        Me.FillByIDToolStripButton.Text = "FillByID"
        '
        'OrderSearchBindingSource
        '
        Me.OrderSearchBindingSource.DataMember = "Customer_OrderSearch"
        Me.OrderSearchBindingSource.DataSource = Me.CustomerBindingSource
        '
        'OrderSearchDataGridView
        '
        Me.OrderSearchDataGridView.AllowUserToAddRows = False
        Me.OrderSearchDataGridView.AllowUserToDeleteRows = False
        Me.OrderSearchDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.OrderSearchDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.OrderSearchDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.OrderSearchDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.OrderID, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.OrderTotal})
        Me.OrderSearchDataGridView.DataSource = Me.OrderSearchBindingSource
        Me.OrderSearchDataGridView.Location = New System.Drawing.Point(414, 439)
        Me.OrderSearchDataGridView.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.OrderSearchDataGridView.Name = "OrderSearchDataGridView"
        Me.OrderSearchDataGridView.ReadOnly = True
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.OrderSearchDataGridView.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.OrderSearchDataGridView.RowHeadersWidth = 51
        Me.OrderSearchDataGridView.RowTemplate.Height = 24
        Me.OrderSearchDataGridView.Size = New System.Drawing.Size(768, 158)
        Me.OrderSearchDataGridView.TabIndex = 27
        '
        'EmployeeBindingSource
        '
        Me.EmployeeBindingSource.DataMember = "Employee"
        Me.EmployeeBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'StoreLocationBindingSource
        '
        Me.StoreLocationBindingSource.DataMember = "StoreLocation"
        Me.StoreLocationBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'CustomerTableAdapter
        '
        Me.CustomerTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CustomerOrderTableAdapter = Nothing
        Me.TableAdapterManager.CustomerTableAdapter = Me.CustomerTableAdapter
        Me.TableAdapterManager.DietProductTableAdapter = Nothing
        Me.TableAdapterManager.DietTableAdapter = Nothing
        Me.TableAdapterManager.EmployeeTableAdapter = Nothing
        Me.TableAdapterManager.EmploymentHistoryTableAdapter = Nothing
        Me.TableAdapterManager.OrderLineTableAdapter = Nothing
        Me.TableAdapterManager.PositionTableAdapter = Nothing
        Me.TableAdapterManager.ProductTableAdapter = Nothing
        Me.TableAdapterManager.ProductTypeTableAdapter = Nothing
        Me.TableAdapterManager.RewardHistoryTableAdapter = Me.RewardHistoryTableAdapter
        Me.TableAdapterManager.RewardStatusTableAdapter = Me.RewardStatusTableAdapter
        Me.TableAdapterManager.StoreLocationTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = BackToRootsForms.BackToRootsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'RewardHistoryTableAdapter
        '
        Me.RewardHistoryTableAdapter.ClearBeforeFill = True
        '
        'RewardStatusTableAdapter
        '
        Me.RewardStatusTableAdapter.ClearBeforeFill = True
        '
        'CustomerOrderTableAdapter
        '
        Me.CustomerOrderTableAdapter.ClearBeforeFill = True
        '
        'EmployeeTableAdapter
        '
        Me.EmployeeTableAdapter.ClearBeforeFill = True
        '
        'StoreLocationTableAdapter
        '
        Me.StoreLocationTableAdapter.ClearBeforeFill = True
        '
        'CustomerBindingSource1
        '
        Me.CustomerBindingSource1.DataMember = "Customer"
        Me.CustomerBindingSource1.DataSource = Me.BackToRootsDataSet
        '
        'OrderPlacementBindingSource
        '
        Me.OrderPlacementBindingSource.DataMember = "OrderPlacement"
        Me.OrderPlacementBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'OrderPlacementTableAdapter
        '
        Me.OrderPlacementTableAdapter.ClearBeforeFill = True
        '
        'OrderFulfillmentBindingSource
        '
        Me.OrderFulfillmentBindingSource.DataMember = "OrderFulfillment"
        Me.OrderFulfillmentBindingSource.DataSource = Me.BackToRootsDataSet
        '
        'OrderFulfillmentTableAdapter
        '
        Me.OrderFulfillmentTableAdapter.ClearBeforeFill = True
        '
        'OrderSearchTableAdapter
        '
        Me.OrderSearchTableAdapter.ClearBeforeFill = True
        '
        'lblTotalSpent
        '
        Me.lblTotalSpent.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTotalSpent.AutoSize = True
        Me.lblTotalSpent.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalSpent.ForeColor = System.Drawing.Color.FromArgb(CType(CType(117, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.lblTotalSpent.Location = New System.Drawing.Point(1051, 610)
        Me.lblTotalSpent.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTotalSpent.Name = "lblTotalSpent"
        Me.lblTotalSpent.Size = New System.Drawing.Size(61, 25)
        Me.lblTotalSpent.TabIndex = 29
        Me.lblTotalSpent.Text = "$0.00"
        Me.lblTotalSpent.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblNextRewardTier
        '
        Me.lblNextRewardTier.AutoSize = True
        Me.lblNextRewardTier.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNextRewardTier.ForeColor = System.Drawing.Color.FromArgb(CType(CType(108, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(118, Byte), Integer))
        Me.lblNextRewardTier.Location = New System.Drawing.Point(546, 414)
        Me.lblNextRewardTier.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblNextRewardTier.Name = "lblNextRewardTier"
        Me.lblNextRewardTier.Size = New System.Drawing.Size(301, 20)
        Me.lblNextRewardTier.TabIndex = 26
        Me.lblNextRewardTier.Text = "Note on amount to next rewards tier."
        '
        'DOBMaskedTextBox
        '
        Me.DOBMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CustomerBindingSource, "CustomerDOB", True, System.Windows.Forms.DataSourceUpdateMode.OnValidation, Nothing, "MM/dd/yyyy"))
        Me.DOBMaskedTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DOBMaskedTextBox.Location = New System.Drawing.Point(771, 334)
        Me.DOBMaskedTextBox.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DOBMaskedTextBox.Mask = "00/00/0000"
        Me.DOBMaskedTextBox.Name = "DOBMaskedTextBox"
        Me.DOBMaskedTextBox.Size = New System.Drawing.Size(179, 27)
        Me.DOBMaskedTextBox.TabIndex = 38
        Me.DOBMaskedTextBox.ValidatingType = GetType(Date)
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.btnClose.Location = New System.Drawing.Point(1141, 34)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(51, 27)
        Me.btnClose.TabIndex = 39
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrderSearchToolStripMenuItem, Me.ManagementToolStripMenuItem, Me.ManagementToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(3, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(1213, 26)
        Me.MenuStrip1.TabIndex = 40
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'OrderSearchToolStripMenuItem
        '
        Me.OrderSearchToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.OrderSearchToolStripMenuItem.Name = "OrderSearchToolStripMenuItem"
        Me.OrderSearchToolStripMenuItem.Size = New System.Drawing.Size(107, 24)
        Me.OrderSearchToolStripMenuItem.Text = "Order Search"
        '
        'ManagementToolStripMenuItem
        '
        Me.ManagementToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrdersToolStripMenuItem, Me.CustomersToolStripMenuItem})
        Me.ManagementToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.ManagementToolStripMenuItem.Name = "ManagementToolStripMenuItem"
        Me.ManagementToolStripMenuItem.Size = New System.Drawing.Size(119, 24)
        Me.ManagementToolStripMenuItem.Text = "Front of House"
        '
        'OrdersToolStripMenuItem
        '
        Me.OrdersToolStripMenuItem.Name = "OrdersToolStripMenuItem"
        Me.OrdersToolStripMenuItem.Size = New System.Drawing.Size(147, 24)
        Me.OrdersToolStripMenuItem.Text = "Orders"
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(147, 24)
        Me.CustomersToolStripMenuItem.Text = "Customers"
        '
        'ManagementToolStripMenuItem1
        '
        Me.ManagementToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RewardStatusToolStripMenuItem})
        Me.ManagementToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.ManagementToolStripMenuItem1.Name = "ManagementToolStripMenuItem1"
        Me.ManagementToolStripMenuItem1.Size = New System.Drawing.Size(109, 24)
        Me.ManagementToolStripMenuItem1.Text = "Management"
        '
        'RewardStatusToolStripMenuItem
        '
        Me.RewardStatusToolStripMenuItem.Name = "RewardStatusToolStripMenuItem"
        Me.RewardStatusToolStripMenuItem.Size = New System.Drawing.Size(172, 24)
        Me.RewardStatusToolStripMenuItem.Text = "Reward Status"
        '
        'RewardStatus
        '
        Me.RewardStatus.DataPropertyName = "RewardStatusID"
        Me.RewardStatus.DataSource = Me.RewardStatusBindingSource
        Me.RewardStatus.DisplayMember = "RewardStatusName"
        Me.RewardStatus.HeaderText = "Reward Status"
        Me.RewardStatus.MinimumWidth = 6
        Me.RewardStatus.Name = "RewardStatus"
        Me.RewardStatus.ReadOnly = True
        Me.RewardStatus.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.RewardStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.RewardStatus.ValueMember = "RewardStatusID"
        Me.RewardStatus.Width = 120
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "RewardStatusJoinDate"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.LightGray
        Me.DataGridViewTextBoxColumn3.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridViewTextBoxColumn3.HeaderText = "Join Date"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Width = 85
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "RewardStatusEndDate"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.LightGray
        Me.DataGridViewTextBoxColumn4.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridViewTextBoxColumn4.HeaderText = "End Date"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Width = 85
        '
        'OrderID
        '
        Me.OrderID.DataPropertyName = "OrderID"
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.LightGray
        Me.OrderID.DefaultCellStyle = DataGridViewCellStyle5
        Me.OrderID.HeaderText = "OrderID"
        Me.OrderID.MinimumWidth = 6
        Me.OrderID.Name = "OrderID"
        Me.OrderID.ReadOnly = True
        Me.OrderID.Width = 65
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "OrderDate"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.LightGray
        Me.DataGridViewTextBoxColumn2.DefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridViewTextBoxColumn2.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 80
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "LocationCity"
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.LightGray
        Me.DataGridViewTextBoxColumn7.DefaultCellStyle = DataGridViewCellStyle7
        Me.DataGridViewTextBoxColumn7.HeaderText = "Location"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 85
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "EmployeeFullName"
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.LightGray
        Me.DataGridViewTextBoxColumn11.DefaultCellStyle = DataGridViewCellStyle8
        Me.DataGridViewTextBoxColumn11.HeaderText = "Employee"
        Me.DataGridViewTextBoxColumn11.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        Me.DataGridViewTextBoxColumn11.Width = 150
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "OrderPlacement"
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.LightGray
        Me.DataGridViewTextBoxColumn13.DefaultCellStyle = DataGridViewCellStyle9
        Me.DataGridViewTextBoxColumn13.HeaderText = "Placement"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.Width = 110
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "OrderFulfillment"
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.LightGray
        Me.DataGridViewTextBoxColumn14.DefaultCellStyle = DataGridViewCellStyle10
        Me.DataGridViewTextBoxColumn14.HeaderText = "Fulfillment"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        Me.DataGridViewTextBoxColumn14.Width = 110
        '
        'OrderTotal
        '
        Me.OrderTotal.DataPropertyName = "OrderTotal"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.LightGray
        DataGridViewCellStyle11.Format = "C2"
        DataGridViewCellStyle11.NullValue = Nothing
        Me.OrderTotal.DefaultCellStyle = DataGridViewCellStyle11
        Me.OrderTotal.HeaderText = "Order Total"
        Me.OrderTotal.MinimumWidth = 6
        Me.OrderTotal.Name = "OrderTotal"
        Me.OrderTotal.ReadOnly = True
        Me.OrderTotal.Width = 95
        '
        'Customers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(178, Byte), Integer), CType(CType(180, Byte), Integer), CType(CType(151, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1213, 669)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.DOBMaskedTextBox)
        Me.Controls.Add(Me.lblNextRewardTier)
        Me.Controls.Add(Me.lblTotalSpent)
        Me.Controls.Add(lblTotalSpentTitle)
        Me.Controls.Add(Me.OrderSearchDataGridView)
        Me.Controls.Add(Me.FillByIDToolStrip)
        Me.Controls.Add(Me.btnRewardsInfo)
        Me.Controls.Add(Me.ZipCodeMaskedTextBox)
        Me.Controls.Add(Me.CustomerPhoneMaskedTextBox)
        Me.Controls.Add(Me.FillByToolStrip)
        Me.Controls.Add(lblOrderHistory)
        Me.Controls.Add(lblCurrentRewardStatusTitle)
        Me.Controls.Add(Me.lblCurrentRewardStatus)
        Me.Controls.Add(lblRewardHistory)
        Me.Controls.Add(Me.RewardHistoryDataGridView)
        Me.Controls.Add(lblCustomerID)
        Me.Controls.Add(Me.txtCustomerID)
        Me.Controls.Add(lblCustomerFirstName)
        Me.Controls.Add(Me.txtCustomerFirstName)
        Me.Controls.Add(lblCustomerLastName)
        Me.Controls.Add(Me.txtCustomerLastName)
        Me.Controls.Add(lblCustomerDOB)
        Me.Controls.Add(lblCustomerEmail)
        Me.Controls.Add(Me.CustomerEmailTextBox)
        Me.Controls.Add(lblCustomerPhoneNumber)
        Me.Controls.Add(lblCustomerStreetAddress)
        Me.Controls.Add(Me.CustomerStreetAddressTextBox)
        Me.Controls.Add(lblCustomerCity)
        Me.Controls.Add(Me.CustomerCityTextBox)
        Me.Controls.Add(lblCustomerState)
        Me.Controls.Add(Me.CustomerStateTextBox)
        Me.Controls.Add(lblCustomerZipCode)
        Me.Controls.Add(Me.CustomerBindingNavigator)
        Me.Controls.Add(Me.lblCustomers)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Name = "Customers"
        Me.Text = "Customers"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CustomerBindingNavigator.ResumeLayout(False)
        Me.CustomerBindingNavigator.PerformLayout()
        CType(Me.CustomerBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BackToRootsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RewardHistoryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RewardHistoryDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RewardStatusBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerOrderBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillByToolStrip.ResumeLayout(False)
        Me.FillByToolStrip.PerformLayout()
        Me.FillByIDToolStrip.ResumeLayout(False)
        Me.FillByIDToolStrip.PerformLayout()
        CType(Me.OrderSearchBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderSearchDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StoreLocationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomerBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderPlacementBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OrderFulfillmentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCustomers As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents BackToRootsDataSet As BackToRootsDataSet
    Friend WithEvents CustomerBindingSource As BindingSource
    Friend WithEvents CustomerTableAdapter As BackToRootsDataSetTableAdapters.CustomerTableAdapter
    Friend WithEvents TableAdapterManager As BackToRootsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CustomerBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents CustomerBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents txtCustomerID As TextBox
    Friend WithEvents txtCustomerFirstName As TextBox
    Friend WithEvents txtCustomerLastName As TextBox
    Friend WithEvents CustomerEmailTextBox As TextBox
    Friend WithEvents CustomerStreetAddressTextBox As TextBox
    Friend WithEvents CustomerCityTextBox As TextBox
    Friend WithEvents CustomerStateTextBox As TextBox
    Friend WithEvents RewardHistoryTableAdapter As BackToRootsDataSetTableAdapters.RewardHistoryTableAdapter
    Friend WithEvents RewardHistoryBindingSource As BindingSource
    Friend WithEvents RewardHistoryDataGridView As DataGridView
    Friend WithEvents RewardStatusTableAdapter As BackToRootsDataSetTableAdapters.RewardStatusTableAdapter
    Friend WithEvents RewardStatusBindingSource As BindingSource
    Friend WithEvents CustomerOrderBindingSource As BindingSource
    Friend WithEvents CustomerOrderTableAdapter As BackToRootsDataSetTableAdapters.CustomerOrderTableAdapter
    Friend WithEvents EmployeeBindingSource As BindingSource
    Friend WithEvents EmployeeTableAdapter As BackToRootsDataSetTableAdapters.EmployeeTableAdapter
    Friend WithEvents StoreLocationBindingSource As BindingSource
    Friend WithEvents StoreLocationTableAdapter As BackToRootsDataSetTableAdapters.StoreLocationTableAdapter
    Friend WithEvents CustomerBindingSource1 As BindingSource
    Friend WithEvents OrderPlacementBindingSource As BindingSource
    Friend WithEvents OrderPlacementTableAdapter As BackToRootsDataSetTableAdapters.OrderPlacementTableAdapter
    Friend WithEvents OrderFulfillmentBindingSource As BindingSource
    Friend WithEvents OrderFulfillmentTableAdapter As BackToRootsDataSetTableAdapters.OrderFulfillmentTableAdapter
    Friend WithEvents lblCurrentRewardStatus As Label
    Friend WithEvents FillByToolStrip As ToolStrip
    Friend WithEvents CustomerLastNameToolStripLabel As ToolStripLabel
    Friend WithEvents txtCustomerLastNameSearch As ToolStripTextBox
    Friend WithEvents FillByToolStripButton As ToolStripButton
    Friend WithEvents btnFillAll As ToolStripButton
    Friend WithEvents CustomerPhoneMaskedTextBox As MaskedTextBox
    Friend WithEvents ZipCodeMaskedTextBox As MaskedTextBox
    Friend WithEvents btnRewardsInfo As Button
    Friend WithEvents FillByIDToolStrip As ToolStrip
    Friend WithEvents CustomerIDToolStripLabel As ToolStripLabel
    Friend WithEvents CustomerIDToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillByIDToolStripButton As ToolStripButton
    Friend WithEvents OrderSearchBindingSource As BindingSource
    Friend WithEvents OrderSearchTableAdapter As BackToRootsDataSetTableAdapters.OrderSearchTableAdapter
    Friend WithEvents OrderSearchDataGridView As DataGridView
    Friend WithEvents lblTotalSpent As Label
    Friend WithEvents lblNextRewardTier As Label
    Friend WithEvents DOBMaskedTextBox As MaskedTextBox
    Friend WithEvents btnClose As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents OrderSearchToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManagementToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrdersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CustomersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManagementToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RewardStatusToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RewardStatus As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents OrderID As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents OrderTotal As DataGridViewTextBoxColumn
End Class
